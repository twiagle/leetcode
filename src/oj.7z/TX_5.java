package oj;

public class TX_5 {
}
