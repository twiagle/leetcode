package oj;

public class TX_3 {

}
